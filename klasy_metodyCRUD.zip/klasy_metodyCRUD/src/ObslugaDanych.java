import java.util.ArrayList;

public class ObslugaDanych {
    //Pole przechowujące listę użytkowników
    private ArrayList<UserData> listaDanych;
    //Konstruktor klasy przyjmujący listę użytkowników jako argument
    public ObslugaDanych(ArrayList<UserData> listaDanych) {
        this.listaDanych = listaDanych;
    }

    //Metoda dodająca nowego użytkownika do listy
    public void dodajUzytkownika(UserData userData) {
        listaDanych.add(userData);
        System.out.println("Użytkownik dodany pomyślnie.");
    }
    //Metoda która wyświetla wszystkich użytkowników na liście
    public void wyswietlWszystkichUzytkownikow() {
        //Pętla która przechodzi przez wszystkich użytkowników na liście
        for (UserData data : listaDanych) {
            System.out.println(data.toString());
        }
    }
    //Metoda modyfikująca dane użytkownika o podanym adresie e-mail
    public void modyfikujDaneUzytkownika(String email, UserData noweDaneUzytkownika) {
        for (UserData data : listaDanych) {
            //Sprawdzenie, czy e-mail bieżącego użytkownika zgadza się z podanym e-mailem i jeżeli tak to ustawia nowe dane
            if (data.getEmail().equals(email)) {
                data.setDataUrodzenia(noweDaneUzytkownika.getDataUrodzenia());
                data.setImie(noweDaneUzytkownika.getImie());
                data.setNazwisko(noweDaneUzytkownika.getNazwisko());
                System.out.println("Dane użytkownika zmodyfikowane.");
                return;
            }
        }
        System.out.println("Nie znaleziono użytkownika o podanym adresie e-mail.");
    }
    //Metoda usuwająca użytkownika o podanym adresie e-mail
    public void usunUzytkownika(String email) {
        listaDanych.removeIf(data -> data.getEmail().equals(email));
        System.out.println("Użytkownik usunięty pomyślnie.");
    }

    //Metoda która sortuje użytkowników według roku urodzenia
    public void sortujDaneWedlugRoku() {
        listaDanych.sort((userData1, userData2) -> {
            //Wyciąga rok z daty urodzenia użytkownika
            String rok1 = userData1.getDataUrodzenia().split("-")[0];
            String rok2 = userData2.getDataUrodzenia().split("-")[0];
            //Porównuje rok urodzenia
            return rok1.compareTo(rok2);
        });
        System.out.println("Dane zostały posortowane wg roku urodzenia.");
    }
}