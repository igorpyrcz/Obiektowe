import java.io.*;
import java.util.ArrayList;

public class ZapisOdczyt {
    //Stała przechowująca dane użytkowników
    private static final String NAZWA_PLIKU = "tajne_dane.txt";

    public static void zapiszDaneDoPliku(ArrayList<UserData> listaDanych) {
        //Użycie try do automatycznego zamknięcia PrintWriter po zakończeniu
        try (PrintWriter writer = new PrintWriter(new FileWriter(NAZWA_PLIKU))) {
            //Iteracja przez listę danych użytkowników i zapisanie każdej pozycji danych użytkownika do pliku
            for (UserData data : listaDanych) {
                writer.println(data.toString());
            }
            System.out.println("Dane zostały zapisane do pliku.");
        } catch (IOException e) {
            System.err.println("Błąd zapisu do pliku: " + e.getMessage());
        }
    }

    public static ArrayList<UserData> wczytajDaneZPliku() {

        //Stworzenie nowej listy, która będzie przechowywać dane użytkowników
        ArrayList<UserData> listaDanych = new ArrayList<>();

        //Użycie try do automatycznego zamknięcia BufferedReader po zakończeniu
        try (BufferedReader reader = new BufferedReader(new FileReader(NAZWA_PLIKU))) {
            String line;

            //Odczytywanie każdej linii z pliku, dopóki są dostępne linie
            while ((line = reader.readLine()) != null) {
                //Dzielenie linii na części, używając średnika jako separatora
                String[] parts = line.split(";");

                //Sprawdzenie, czy linia zawiera dokładnie cztery części
                if (parts.length == 4) {
                    String email = parts[0];
                    String birthDate = parts[1];
                    String firstName = parts[2];
                    String lastName = parts[3];

                    //Dodanie nowego obiektu UserData do listy
                    listaDanych.add(new UserData(email, birthDate, firstName, lastName));
                }
            }
        } catch (IOException e) {
            System.err.println("Błąd odczytu pliku: " + e.getMessage());
        }
        return listaDanych;
    }
}