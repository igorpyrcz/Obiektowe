import java.util.Scanner;

public class Menu {
    //Deklaracja prywatnego pola klasy typu Scanner, używanego do pobierania danych od użytkownika
    private Scanner skaner = new Scanner(System.in);
    //Metoda wyświetlająca menu i pobierająca odpowiedz od użytkownika
    public int wyswietlMenuIUzyskajOdpowiedz() {
        System.out.println("Wybierz akcję:");
        System.out.println("1. Dodaj nowego użytkownika");
        System.out.println("2. Wyświetl wszystkich użytkowników");
        System.out.println("3. Zmień dane użytkownika");
        System.out.println("4. Usuń użytkownika");
        System.out.println("0. Zakończ program");

        return skaner.nextInt();
    }
    //Metoda pobierająca dane użytkownika które wprowadził
    public UserData pobierzDaneUzytkownika() {
        System.out.println("Podaj e-mail:");
        String email = skaner.next();

        System.out.println("Podaj datę urodzenia (RRRR-MM-DD):");
        String dataUrodzenia = skaner.next();

        System.out.println("Podaj imię:");
        String imie = skaner.next();

        System.out.println("Podaj nazwisko:");
        String nazwisko = skaner.next();

        //Stworzenie nowego obiektu UserData z podanymi danymi i zwracanie go
        return new UserData(email, dataUrodzenia, imie, nazwisko);
    }
    //Metoda która pobiera e-mail użytkownika i go zwraca
    public String pobierzEmailOdUzytkownika() {
        System.out.println("Podaj e-mail użytkownika:");
        return skaner.next();
    }
}