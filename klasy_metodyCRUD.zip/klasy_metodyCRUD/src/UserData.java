public class UserData {
    private String email;
    private String dataUrodzenia;
    private String imie;
    private String nazwisko;

    //Konstruktor, gettery, settery
    public UserData(String email, String dataUrodzenia, String imie, String nazwisko) {
        this.email = email;
        this.dataUrodzenia = dataUrodzenia;
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    //Gettery i settery
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDataUrodzenia() {
        return dataUrodzenia;
    }

    public void setDataUrodzenia(String dataUrodzenia) {
        this.dataUrodzenia = dataUrodzenia;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    @Override
    public String toString() {
        return email + ";" + dataUrodzenia + ";" + imie + ";" + nazwisko;
    }
}