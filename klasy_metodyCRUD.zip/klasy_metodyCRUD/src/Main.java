import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        //Wczytanie danych z pliku
        ArrayList<UserData> listaDanych = ZapisOdczyt.wczytajDaneZPliku();

        //Tworzenie nowego obiektu klasy odpowiedzialnego za obsługę danych
        ObslugaDanych obslugaDanych = new ObslugaDanych(listaDanych);

        //Inicjalizacja obiektu do wyświetlania menu
        Menu menu = new Menu();

        int wybor;
        do {
            //Wyświetlenie menu i pobranie odpowiedzi od użytkownika
            wybor = menu.wyswietlMenuIUzyskajOdpowiedz();

            //Instrukacja warunkowa switch odpowiedzialna za wykonanie odpowiedniej akcji na podstawie wyboru użytkownika
            switch (wybor) {
                case 1:
                    UserData nowyUzytkownik = menu.pobierzDaneUzytkownika();
                    obslugaDanych.dodajUzytkownika(nowyUzytkownik);
                    break;
                case 2:
                    obslugaDanych.wyswietlWszystkichUzytkownikow();
                    break;
                case 3:
                    String emailDoModyfikacji = menu.pobierzEmailOdUzytkownika();
                    UserData noweDaneUzytkownika = menu.pobierzDaneUzytkownika();
                    obslugaDanych.modyfikujDaneUzytkownika(emailDoModyfikacji, noweDaneUzytkownika);
                    break;
                case 4:
                    String emailDoUsuniecia = menu.pobierzEmailOdUzytkownika();
                    obslugaDanych.usunUzytkownika(emailDoUsuniecia);
                    break;
                case 5:
                    obslugaDanych.sortujDaneWedlugRoku();
                    break;
                case 0:
                    ZapisOdczyt.zapiszDaneDoPliku(listaDanych);
                    System.out.println("Program zakończony.");
                    break;
                default:
                    System.out.println("Nieprawidłowy wybór.");
                    break;
            }
        }
        //Pętla która wykonuje się dopóki użytkownik nie wybierze opcji zakończenia programu
        while (wybor != 0);
    }
}