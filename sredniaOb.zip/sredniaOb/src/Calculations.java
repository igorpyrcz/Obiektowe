import java.lang.Math;

public class Calculations {
    //Metoda obliczająca wariacje
    public double varation(int[] grades,int[] weights){

        //Zmienna przechowująca sumę wag
        double weightsAddition=0;

        //Zmienna przechowująca średnią wartość
        double average=0;

        //Zmienna przechowująca wariację
        double varation=0;

        //Tablica przechowująca oceny po uwzględnieniu wag
        double[] gradesAfterWeight=new double[10];

        //Obliczanie ocen po uwzględnieniu wag
        for(int i=0;i< grades.length;i++){
            gradesAfterWeight[i]=grades[i]*weights[i];
        }

        //Obliczanie sumy wag
        for(int i=0;i< weights.length;i++){
            weightsAddition+= weights[i];
        }

        // Obliczanie średniej wartości
        for(int i=0;i< gradesAfterWeight.length;i++){
            average+= gradesAfterWeight[i];
        }
        average=average/gradesAfterWeight.length;

        // Obliczanie wariacji
        for(int i=0;i< grades.length;i++){
            varation=varation+(Math.pow(grades[i],2)*weights[i]);
        }
        // Obliczanie wariacji, dzielenie przez sumę wag, odejmowanie średniej, obliczanie pierwiastka kwadratowego, zaokrąglanie do dwóch miejsc po przecinku
        varation=varation/weightsAddition;
        varation=varation-average;
        varation=Math.sqrt(varation);
        varation=Math.round(varation*100.0)/100.0;
        return varation;
    }
}
