import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //Stworzenie obiektu klasy Calculations
        Calculations calc=new Calculations();

        //Stworzenie obiektu klasy Random do generowania losowych liczb
        Random rand=new Random();

        //Inicjalizacja tablic na oceny i wagi
        int[] grades=new int[10];
        int[] weight=new int[10];

        //Wypełnianie tablic losowymi ocenami i wagami
        for(int i=0;i<grades.length;i++){
            grades[i]= rand.nextInt(6)+1; // Losowanie liczby z zakresu 1-6 (oceny)
            weight[i]= rand.nextInt(5)+1; // Losowanie liczby z zakresu 1-5 (wagi)
        }

        //Wyświetlanie ocen i wag
        for(int i=0;i<grades.length;i++){
            //Sprawdzenie czy ocena i waga są prawidłowe
            if(weight[i]<1 || weight[i]>5 && grades[i]<1 || grades[i]>6){
                System.out.println(grades[i]+" "+weight[i]+" "+"Ocena i waga nieprawidłowe");
            }
            //Sprawdzenie czy ocena jest prawidłowa
            if(grades[i]<1 || grades[i]>6){
                System.out.println("Nieprawidłowa ocena");
            }
            //Sprawdzenie czy waga jest prawidłowa
            if(weight[i]<1 || weight[i]>5){
                System.out.println("Waga oceny nieprawidłowa.");
            }
        }

        //Wyświetlanie ocen i wag
        for(int i=0;i<grades.length;i++){
            System.out.println(grades[i]+"  "+weight[i]);
        }

        //Wyświetlanie wariacji
        System.out.println("Wariacja: "+calc.varation(grades,weight));

        //Wyświetlanie odchylenia standardowego
        System.out.println("Odchylenie standardowe: "+Math.round((Math.sqrt(calc.varation(grades,weight)))*100.0)/100.0);
    }
}
